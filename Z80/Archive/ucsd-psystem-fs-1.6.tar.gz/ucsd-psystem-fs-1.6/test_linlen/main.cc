//
// UCSD p-System filesystem in user space
// Copyright (C) 2006, 2007 Peter Miller
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or (at
// you option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program. If not, see <http://www.gnu.org/licenses/>
//

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>

#include <lib/progname.h>
#include <lib/quit.h>
#include <lib/version.h>
#include <test_linlen/check.h>


static void
usage(void)
{
    const char *prog = progname_get();
    fprintf(stderr, "Usage: %s <filename>...\n", prog);
    fprintf(stderr, "       %s -f <filename>\n", prog);
    exit(1);
}


static void
process(const char *filename)
{
    FILE *fp = stdin;
    if (0 != strcmp(filename, "-"))
    {
        fp = fopen(filename, "r");
        if (!fp)
            quitter.fatal_error_with_errno("open %s", filename);
    }
    for (;;)
    {
        char buffer[4000];
        if (!fgets(buffer, sizeof(buffer), fp))
            break;
        size_t len = strlen(buffer);
        if (len > 0 && buffer[len - 1] == '\n')
            buffer[len - 1] = 0;
        check(buffer);
    }
    if (fp != stdin)
        fclose(fp);
}


int
main(int argc, char **argv)
{
    progname_set(argv[0]);
    for (;;)
    {
        int c = getopt(argc, argv, "f:Vw");
        if (c == EOF)
            break;
        switch (c)
        {
        case 'f':
            process(optarg);
            break;

        case 'w':
            warning = true;
            break;

        case 'V':
            version_print();
            return 0;

        default:
            usage();
        }
    }
    while (optind < argc)
        check(argv[optind++]);
    return 0;
}
