//
// UCSD p-System filesystem in user space
// Copyright (C) 2006-2008 Peter Miller
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or (at
// you option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program. If not, see <http://www.gnu.org/licenses/>
//

#include <cassert>
#include <cerrno>
#include <sys/types.h>
#include <sys/stat.h>

#include <lib/input/psystem.h>
#include <lib/directory/entry.h>
#include <lib/quit.h>


input_psystem::~input_psystem()
{
    assert(dep);
    int err = dep->flush();
    if (err < 0)
    {
        errno = -err;
        quitter.fatal_error_with_errno("flush %s", name().quote_c().c_str());
    }
    err = dep->release();
    if (err < 0)
    {
        errno = -err;
        quitter.fatal_error_with_errno("release %s", name().quote_c().c_str());
    }
    dep = 0;
}


input_psystem::input_psystem(directory_entry *a_dep) :
    dep(a_dep),
    address(0)
{
    assert(dep);
    int err = dep->open();
    if (err < 0)
    {
        errno = -err;
        quitter.fatal_error_with_errno("open %s", name().quote_c().c_str());
    }
}


input::pointer
input_psystem::create(directory_entry::pointer a_dep)
{
    return pointer(new input_psystem(a_dep.get()));
}


input::pointer
input_psystem::create(directory_entry *a_dep)
{
    return pointer(new input_psystem(a_dep));
}


long
input_psystem::read_inner(void *data, size_t size)
{
    long n = dep->read(address, data, size);
    if (n < 0)
    {
        errno = -n;
        quitter.fatal_error("read %s", name().quote_c().c_str());
    }
    address += n;
    return n;
}


void
input_psystem::fstat(struct stat &st)
{
    int rc = dep->getattr(&st);
    if (rc < 0)
    {
        errno = -rc;
        quitter.fatal_error("fstat %s", name().quote_c().c_str());
    }
}


int
input_psystem::fpathconf_name_max()
{
    return dep->get_name_maxlen();
}


rcstring
input_psystem::name()
{
    return dep->get_full_name();
}


long
input_psystem::length()
{
    struct stat st;
    fstat(st);
    return st.st_size;
}
