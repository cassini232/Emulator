//
// UCSD p-System filesystem in user space
// Copyright (C) 2006-2008 Peter Miller
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or (at
// you option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program. If not, see <http://www.gnu.org/licenses/>
//

#include <cerrno>
#include <cstdio>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <lib/input/stdin.h>
#include <lib/quit.h>


input_stdin::~input_stdin()
{
}


input_stdin::input_stdin() :
    pos(0),
    unbuffered(false)
{
}


input::pointer
input_stdin::create()
{
    return pointer(new input_stdin());
}


long
input_stdin::read_inner(void *data, size_t len)
{
    if (len <= 0)
        return 0;
    if (unbuffered)
        len = 1;
    int fd = fileno(stdin);
    long result = ::read(fd, data, len);
    if (result < 0)
        quitter.fatal_error_with_errno("read standard input");
    pos += result;
    return result;
}


rcstring
input_stdin::name()
{
    return "standard input";
}


long
input_stdin::length()
{
    struct stat st;
    if (::fstat(fileno(stdin), &st) < 0)
        return -errno;
    if (!S_ISREG(st.st_mode))
        return -EINVAL;
    return st.st_size;
}


int
input_stdin::fpathconf_name_max()
{
    long n = fpathconf(fileno(stdin), _PC_NAME_MAX);
    if (n < 0)
        return -errno;
    return n;
}


void
input_stdin::fstat(struct stat &st)
{
    if (::fstat(fileno(stdin), &st) < 0)
        quitter.fatal_error_with_errno("fstat standard input");
}
