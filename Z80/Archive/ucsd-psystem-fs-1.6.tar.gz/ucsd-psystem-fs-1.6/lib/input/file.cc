//
// UCSD p-System filesystem in user space
// Copyright (C) 2006-2008 Peter Miller
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or (at
// you option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program. If not, see <http://www.gnu.org/licenses/>
//

#include <cassert>
#include <cerrno>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <lib/input/file.h>
#include <lib/quit.h>


input_file::~input_file()
{
    if (fd >= 0)
    {
        ::close(fd);
        fd = -1;
    }
}


static int
open_with_stale_nfs_retry(const char *path, int mode)
{
    //
    // Try to open the file.
    //
    errno = 0;
    int perms = 0666;
    int fd = open(path, mode, perms);

    //
    // Keep trying for one minute if we get a Stale NFS file handle
    // error.  Some systems suffer from this in a Very Bad Way.
    //
#ifdef ESTALE
    const int nsecs = 5;
    for (int ntries = 0; ntries < 60; ntries += nsecs)
    {
        if (fd >= 0)
            break;
        if (errno != ESTALE)
            break;
        sleep(nsecs);
        errno = 0;
        fd = open(path, mode, perms);
    }
#endif

    //
    // Return the result, both success and failure.
    // Errors are handled elsewhere.
    //
    return fd;
}


input_file::input_file(const rcstring &a_path) :
    path(a_path),
    fd(-1),
    pos(0)
{
    int mode = O_RDONLY;
#if defined(__CYGWIN__) || defined(__CYGWIN32__)
    // I'm not sure whether MacOsX uses \r or \n in its native text
    // files, so I'm reluctant to always use the O_BINARY mode bit.
    mode |= O_BINARY;
#endif
    fd = open_with_stale_nfs_retry(path.c_str(), mode);
    if (fd < 0)
        quitter.fatal_error_with_errno("open %s", path.c_str());
}


input::pointer
input_file::create(const rcstring &a_path)
{
    return pointer(new input_file(a_path));
}


long
input_file::read_inner(void *data, size_t len)
{
    if (len == 0)
        return 0;
    if (fd < 0)
        return -EBADF;
    ssize_t result = ::read(fd, data, len);
    if (result < 0)
        quitter.fatal_error_with_errno("read %s", path.quote_c().c_str());
    pos += result;
    return result;
}


rcstring
input_file::name()
{
    return path;
}


long
input_file::length()
{
    if (fd < 0)
        return -EBADF;
    struct stat st;
    if (::fstat(fd, &st) < 0)
        quitter.fatal_error_with_errno("fstat %s", path.quote_c().c_str());
    return st.st_size;
}


int
input_file::fpathconf_name_max()
{
    if (fd < 0)
        return -EBADF;
    long n = fpathconf(fd, _PC_NAME_MAX);
    if (n < 0)
        return -errno;
    return n;
}


void
input_file::fstat(struct stat &st)
{
    assert(fd >= 0);
    if (::fstat(fd, &st) < 0)
        quitter.fatal_error_with_errno("fstat %s", path.quote_c().c_str());
}
