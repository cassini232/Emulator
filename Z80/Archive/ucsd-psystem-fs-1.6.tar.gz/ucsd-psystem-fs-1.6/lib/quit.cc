//
//      UCSD p-System filesystem in user space
//      Copyright (C) 2006, 2007 Peter Miller
//
//      This program is free software; you can redistribute it and/or modify
//      it under the terms of the GNU General Public License as published by
//      the Free Software Foundation; either version 3 of the License, or
//      (at your option) any later version.
//
//      This program is distributed in the hope that it will be useful,
//      but WITHOUT ANY WARRANTY; without even the implied warranty of
//      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//      GNU General Public License for more details.
//
//      You should have received a copy of the GNU General Public License
//      along with this program. If not, see
//      <http://www.gnu.org/licenses/>.
//

#pragma implementation "quit"

#include <cerrno>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <grp.h>
#include <pwd.h>
#include <unistd.h>

#include <lib/quit.h>


quit::quit()
{
}


quit::quit(const quit &arg)
{
}


quit &
quit::operator=(const quit &arg)
{
    return *this;
}


quit::~quit()
{
}


void
quit::fatal_error(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    fatal_error_v(fmt, ap);
    va_end(ap);
}


void
quit::fatal_error_v(const char *fmt, va_list ap)
{
    message_v(fmt, ap);
    exit(1);
}


void
quit::fatal_error_with_errno(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    fatal_error_with_errno_v(fmt, ap);
    va_end(ap);
}


void
quit::fatal_error_with_errno_v(const char *fmt, va_list ap)
{
    int err = errno;
    char buffer[1024];
    vsnprintf(buffer, sizeof(buffer), fmt, ap);

    char user[30];
    char group[30];
    char id[60];
    id[0] = 0;
    switch (err)
    {
    case EPERM:
    case EACCES:
#ifndef DO_NOT_USE_GETPWUID
        struct passwd *pw = getpwuid(geteuid());
        if (pw)
            snprintf(user, sizeof(user), "user %s", pw->pw_name);
        else
#endif
            snprintf(user, sizeof(user), "uid %d", geteuid());
#ifndef DO_NOT_USE_GETPWUID
        struct group *gr = getgrgid(getegid());
        if (pw)
            snprintf(group, sizeof(group), "group %s", gr->gr_name);
        else
#endif
            snprintf(group, sizeof(group), "gid %d", geteuid());
        snprintf(id, sizeof(id), " [%s, %s]", user, group);
        break;
    }

    fatal_error("%s: %s%s", buffer, strerror(err), id);
}


void
quit::warning(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    warning_v(fmt, ap);
    va_end(ap);
}


void
quit::warning_v(const char *fmt, va_list ap)
{
    char buf[1024];
    vsnprintf(buf, sizeof(buf), fmt, ap);
    message("warning: %s", buf);
}


void
quit::message(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    message_v(fmt, ap);
    va_end(ap);
}


void
quit::exit(int exit_status)
{
    atexit.run(exit_status);
    exit_inner(exit_status);
}


void
quit::register_atexit(quit_atexit *p)
{
    atexit.push_back(p);
}
