//
// UCSD p-System filesystem in user space
// Copyright (C) 2007 Peter Miller
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or (at
// you option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program. If not, see <http://www.gnu.org/licenses/>
//

#include <cassert>
#include <cerrno>
#include <cstring>

#include <lib/sector_io/imd.h>
#include <lib/debug.h>
#include <lib/quit.h>

// 6. IMAGE FILE FORMAT
//
// The overall layout of an ImageDisk .IMD image file is:
//
// IMD v.vv: dd/mm/yyyy hh:mm:ss          (ASCII Header)
// Comment (ASCII only - unlimited size)  (NOTE:  You can TYPE a .IMD)
// 1A byte - ASCII EOF character          (file to see header/comment)
// - For each track on the disk:
//   1 byte  Mode value                  (0-5)
//   1 byte  Cylinder                    (0-n)
//   1 byte  Head                        (0-1)   (see Note)
//   1 byte  number of sectors in track  (1-n)
//   1 byte  sector size                 (0-6)
//   sector numbering map                * number of sectors
//   sector cylinder map (optional)      * number of sectors
//   sector head map     (optional)      * number of sectors
//   sector data records                 * number of sectors
// <End of file>
//
// 6.1 Mode value
//
// This value indicates the data transfer rate and density  in  which
// the original track was recorded:
//
//   00 = 500 kbps FM   \   Note:   kbps indicates transfer rate,
//   01 = 300 kbps FM    >          not the data rate, which is
//   02 = 250 kbps FM   /           1/2 for FM encoding.
//   03 = 500 kbps MFM
//   04 = 300 kbps MFM
//   05 = 250 kbps MFM
//
// 6.2 Sector size
//
// The Sector Size value indicates the actual size of the sector data
// occuring on the track:
//
//   00 =  128 bytes/sector
//   01 =  256 bytes/sector
//   02 =  512 bytes/sector
//   03 = 1024 bytes/sector
//   04 = 2048 bytes/sector
//   05 = 4096 bytes/sector
//   06 = 8192 bytes/sector
//
// 6.3 Head value
//
// This value indicates the side of the disk on which this track
// occurs (0 or 1).
//
// Since HEAD can only be 0 or 1, ImageDisk uses the upper bits of
// this byte to indicate the presense of optional items in the track
// data:
//
//   Bit 7 (0x80) = Sector Cylinder Map
//   Bit 6 (0x40) = Sector Head     Map
//
// 6.4 Sector numbering map
//
// The sector numbering map contains one byte entry containing the
// physical ID for each sector that occurs in the track.
//
// Note that these entries may NOT be sequential.  A disk which uses
// sector interleave will have a sector numbering map in which the
// sector numbers occur in non-sequential order.
//
// If ImageDisk is unable to obtain all sector numbers in a single
// revolution of the disk, it will report "Unable to determine
// interleave" and rearrange the sector numbers into a simple
// sequential list.
//
// 6.5 Sector Cylinder Map
//
// This is an optional field.  It's presense is indicated by bit 7
// being set in the Head value for the track.
//
// When present, it means that the cylinder values written to the
// sectors do NOT match the physical cylinder of the track.
//
// The Sector Cylinder Map has one entry for each sector, and
// contains the logical Cylinder ID for the corresponding sector in
// the Sector Numbering Map.
//
// Reading a disk with non-standard Cylinder IDs will require the
// use of the FULL ANALYSIS setting.
//
// 6.6 Sector Head map
//
// This is an optional field.  It's presense is indicated by bit 6
// being set in the Head value for the track.
//
// When present, it means that the head values written to the sectors
// do NOT match the physical head selection of the track.
//
// The Sector Head Map has one entry for each sector, and contains
// the logical Head ID for the corresponding sector in the Sector
// Numbering Map.
//
// Reading a disk with non-standard Head ID's may require the use of
// the FULL ANALYSIS setting.
//
// 6.7 Sector Data Records
//
// For each sector ID occuring in the Sector Numbering Map, ImageDisk
// records a Sector Data Record - these records occur in the same
// order as the IDs in the Sector Numbering Map:
//
//   00      Sector data unavailable - could not be read
//   01 ...  Normal data: (Sector Size) bytes follow
//   02 xx   Compressed: All bytes in sector have same value (xx)
//   03 ...  Normal data with "Deleted-Data address mark"
//   04 xx   Compressed with "Deleted-Data address mark"
//   05 .... Normal data read with data error
//   06 xx   Compressed read with data error
//   07 .... Deleted data read with data error
//   08 xx   Compressed, Deleted read with data error
//

sector_io_imd::~sector_io_imd()
{
    DEBUG(2, "%s", __PRETTY_FUNCTION__);
    for (size_t j = 0; j < tracks_count; ++j)
        delete tracks[j];
    delete [] tracks;
    delete [] data;
}


sector_io_imd::sector_io_imd(const rcstring &filename) :
    err(0),
    tracks(0),
    tracks_count(0),
    tracks_count_max(0),
    data_size_in_bytes(0),
    data(0)
{
    DEBUG(2, "%s", __PRETTY_FUNCTION__);
    //
    // Open the file
    //
    FILE *fp = fopen(filename.c_str(), "rb");
    if (!fp)
    {
        DEBUG(2, "file failed to open");
        err = -errno;
        return;
    }

    //
    // Read the file magic number and comment.
    //
    char buffer[2048];
    char *bp = buffer;
    for (;;)
    {
        int c = getc(fp);
        if (c == EOF)
        {
            DEBUG(2, "EOF before end of header");
            goto oops;
        }
        if (c == 0x1A)
            break;
        if (bp < buffer + sizeof(buffer))
            *bp++ = c;
    }
    if (bp - buffer < 4 || 0 != memcmp(buffer, "IMD ", 4))
    {
        DEBUG(2, "wrong magic number");
        goto oops;
    }

    //
    // Read all the tracks
    //
    while (read_track(fp))
        ;
    if (err != 0)
    {
        DEBUG(2, "track read failed");
        oops:
        if (!err)
            err = (ferror(fp) ? -errno : -EINVAL);
        fclose(fp);
        return;
    }
    if (tracks_count == 0)
    {
        DEBUG(2, "zero tracks");
        goto oops;
    }
    fclose(fp);

    //
    // consolidate all of the tracks
    //
    DEBUG(2, "data_size_in_bytes = %d", int(data_size_in_bytes));
    assert(data_size_in_bytes > 0);
    DEBUG(2, "mark");
    assert((data_size_in_bytes & 127) == 0);
    DEBUG(2, "mark");
    data = new unsigned char [data_size_in_bytes];
    DEBUG(2, "data = %p", data);
    unsigned char *dp = data;
    DEBUG(2, "tracks = %p", tracks);
    for (size_t j = 0; j < tracks_count; ++j)
    {
        DEBUG(2, "dp = %p", dp);
        track *tp = tracks[j];
        DEBUG(2, "track %d = %p", j, tp);
        memcpy(dp, tp->data, tp->data_size_in_bytes);
        dp += tp->data_size_in_bytes;
    }
    DEBUG(2, "dp = %p", dp);
    DEBUG(2, "data + data_size_in_bytes = %p", data + data_size_in_bytes);
    assert(dp == data + data_size_in_bytes);

    DEBUG(2, "free tracks");
    for (size_t j = 0; j < tracks_count; ++j)
        delete tracks[j];
    delete [] tracks;
    tracks = 0;
    tracks_count = 0;
    tracks_count_max = 0;
    if (err != 0)
    {
        quitter.fatal_error
        (
            "file %s not in .IMD format",
            filename.quote_c().c_str()
        );
    }
}


sector_io::pointer
sector_io_imd::create(const rcstring &filename, bool read_only)
{
    DEBUG(2, "%s", __PRETTY_FUNCTION__);
    if (!read_only)
    {
        quitter.fatal_error
        (
            "%s: the .IMD format is only supported for read-only access",
            filename.c_str()
        );
    }
    return pointer(new sector_io_imd(filename));
}


bool
sector_io_imd::candidate(const rcstring &filename)
{
    DEBUG(2, "%s", __PRETTY_FUNCTION__);
    FILE *fp = fopen(filename.c_str(), "rb");
    if (!fp)
        return false;
    char buffer[4];
    if (fread(buffer, 1, 4, fp) != 4)
    {
        fclose(fp);
        return false;
    }
    fclose(fp);
    return (0 == memcmp(buffer, "IMD ", 4));
}


bool
sector_io_imd::read_track(FILE *fp)
{
    DEBUG(2, "%s", __PRETTY_FUNCTION__);
    int mode = getc(fp);
    if (mode == EOF)
    {
        if (ferror(fp))
            err = -errno;
        return false;
    }
    if (mode >= 6)
    {
        err = -EINVAL;
        return false;
    }
    track *tp = new track;
    err = tp->read(fp);
    if (err != 0)
    {
        DEBUG(2, "track read failed");
        delete tp;
        return false;
    }
    data_size_in_bytes += tp->data_size_in_bytes;

    if (tracks_count >= tracks_count_max)
    {
        size_t new_tracks_count_max = tracks_count_max * 2 + 16;
        track **new_tracks = new track * [new_tracks_count_max];
        for (size_t j = 0; j < tracks_count; ++j)
            new_tracks[j] = tracks[j];
        delete [] tracks;
        tracks = new_tracks;
        tracks_count_max = new_tracks_count_max;
    }
    tracks[tracks_count++] = tp;
    DEBUG(2, "track read successful");
    return true;
}


sector_io_imd::track::~track()
{
    DEBUG(2, "%s", __PRETTY_FUNCTION__);
    delete [] sector_map;
    delete [] data;
}


sector_io_imd::track::track() :
    cylinder(0),
    head(0),
    sectors(0),
    sector_size(0),
    sector_map(0),
    data_size_in_bytes(0),
    data(0)
{
    DEBUG(2, "%s", __PRETTY_FUNCTION__);
}


int
sector_io_imd::track::read(FILE *fp)
{
    DEBUG(2, "%s", __PRETTY_FUNCTION__);
    int c = getc(fp);
    if (c == EOF)
    {
        DEBUG(2, "bad cylinder %d", c);
        oops:
        return (ferror(fp) ? -errno : -EINVAL);
    }
    cylinder = c;

    c = getc(fp);
    if (c == EOF)
    {
        DEBUG(2, "bad head %d", c);
        goto oops;
    }
    head = c;
    bool cylinder_map_present = ((head & 0x80) != 0);
    bool head_map_present = ((head & 0x40) != 0);
    head &= 1;

    c = getc(fp);
    if (c == EOF)
    {
        DEBUG(2, "bad sectors %d", c);
        goto oops;
    }
    sectors = c;

    c = getc(fp);
    if (c == EOF || c >= 7)
    {
        DEBUG(2, "bad secord size code %d", c);
        goto oops;
    }
    sector_size = 128 << c;

    sector_map = new unsigned char [sectors];
    if (fread(sector_map, 1, sectors, fp) != sectors)
    {
        DEBUG(2, "sector map read fail");
        goto oops;
    }
    for (unsigned j = 0; j < sectors; ++j)
    {
        sector_map[j]--;
        DEBUG(2, "sector_map[%d] = %d", j, sector_map[j]);
    }

    if (cylinder_map_present)
    {
        char junk[256];
        if (fread(junk, 1, sectors, fp) != sectors)
        {
            DEBUG(2, "clyinder map read fail");
            goto oops;
        }
    }

    if (head_map_present)
    {
        char junk[256];
        if (fread(junk, 1, sectors, fp) != sectors)
        {
            DEBUG(2, "head map read fail");
            goto oops;
        }
    }

    data_size_in_bytes = sectors * sector_size;
    DEBUG(2, "track data size = %d", int(data_size_in_bytes));
    data = new unsigned char [data_size_in_bytes];
    DEBUG(2, "track data = %p", data);

    for (unsigned j = 0; j < sectors; ++j)
    {
        if (sector_map[j] >= sectors)
        {
            DEBUG(2, "sector_map[%d] = %d/%d", j, sector_map[j], sectors);
            goto oops;
        }
        unsigned char *p = data + sector_map[j] * sector_size;
        c = getc(fp);
        switch (c)
        {
        case 0:
            // sector data unavailable
            DEBUG(1, "data for sector %d unavailable", j);
            memset(p, 0, sector_size);
            break;

        case 1:
            // normal data
            if (fread(p, 1, sector_size, fp) != sector_size)
            {
                DEBUG(2, "sector data read failed");
                goto oops;
            }
            break;

        case 2:
            // compressed data
            c = getc(fp);
            if (c == EOF)
            {
                DEBUG(2, "sector data read failed");
                goto oops;
            }
            memset(p, c, sector_size);
            break;

        default:
            quitter.fatal_error("unknown sector code %d", c);
            DEBUG(2, "unknown sector code %d", c);
            goto oops;
        }
    }
    delete [] sector_map;
    sector_map = 0;
    return 0;
}


int
sector_io_imd::read_sector(unsigned sector_number, void *o_data)
{
    DEBUG(2, "sector_io_imd::read_sector(this = %p, sector_number = %u, "
        "o_data = %p)", this, sector_number, o_data);
    off_t offset = (off_t)sector_number * 128;
    return read(offset, o_data, 128);
}


int
sector_io_imd::read(off_t offset, void *o_data, size_t size)
{
    DEBUG(2, "sector_io_imd::read(this = %p, offset = 0x%lX, data = %p, "
        "size = 0x%lX)", this, (long)offset, o_data, (long)size);
    if (err)
        return err;
    if (offset < 0)
        return -EINVAL;
    if (offset + size > data_size_in_bytes)
        return -ENOSPC;
    memcpy(o_data, data + offset, size);
    return size;
}


int
sector_io_imd::write_sector(unsigned sector_number, const void *o_data)
{
    DEBUG(2, "sector_io_imd::write_sector(this = %p, sector_number = %u, "
        "o_data = %p)", this, sector_number, o_data);
    return (err ? err : -EROFS);
}


int
sector_io_imd::write(off_t offset, const void *o_data, size_t size)
{
    DEBUG(2, "sector_io_imd::write(this = %p, offset = 0x%lX, o_data = %p, "
        "size = 0x%lX)", this, (long)offset, o_data, (long)size);
    return (err ? err : -EROFS);
}


int
sector_io_imd::size_in_sectors()
{
    DEBUG(2, "%s", __PRETTY_FUNCTION__);
    DEBUG(2, "return %d\n", (int)(data_size_in_bytes >> 7));
    return (data_size_in_bytes >> 7);
}


unsigned
sector_io_imd::bytes_per_sector()
    const
{
    DEBUG(2, "%s", __PRETTY_FUNCTION__);
    return 128;
}


bool
sector_io_imd::is_read_only()
    const
{
    DEBUG(2, "%s", __PRETTY_FUNCTION__);
    return true;
}


unsigned
sector_io_imd::size_multiple_in_bytes()
    const
{
    DEBUG(2, "%s", __PRETTY_FUNCTION__);
    return 128;
}


int
sector_io_imd::sync()
{
    DEBUG(2, "%s", __PRETTY_FUNCTION__);
    return 0;
}
