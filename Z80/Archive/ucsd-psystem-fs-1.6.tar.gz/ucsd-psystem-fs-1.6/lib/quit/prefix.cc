//
//      UCSD p-System filesystem in user space
//      Copyright (C) 2006, 2007 Peter Miller
//
//      This program is free software; you can redistribute it and/or modify
//      it under the terms of the GNU General Public License as published by
//      the Free Software Foundation; either version 3 of the License, or
//      (at your option) any later version.
//
//      This program is distributed in the hope that it will be useful,
//      but WITHOUT ANY WARRANTY; without even the implied warranty of
//      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//      GNU General Public License for more details.
//
//      You should have received a copy of the GNU General Public License
//      along with this program. If not, see
//      <http://www.gnu.org/licenses/>.
//

#pragma implementation "quit_prefix"

#include <cstdio>
#include <cstdarg>
#include <lib/quit/prefix.h>


quit_prefix::quit_prefix(quit &a1, const char *a2) :
    prefix(a2), deeper(a1)
{
}


quit_prefix::quit_prefix(quit &a1, const string &a2) :
    prefix(a2), deeper(a1)
{
}


quit_prefix::quit_prefix(const quit_prefix &arg) :
    prefix(arg.prefix), deeper(arg.deeper)
{
}


quit_prefix &
quit_prefix::operator=(const quit_prefix &arg)
{
    if (this != &arg)
    {
        prefix = arg.prefix;
        deeper = arg.deeper;
    }
    return *this;
}


quit_prefix::~quit_prefix()
{
}


void
quit_prefix::exit_inner(int n)
{
    deeper.exit(n);
}


void
quit_prefix::message_v(const char *fmt, va_list ap)
{
    if (prefix != string(""))
    {
        char buf[1024];
        vsnprintf(buf, sizeof(buf), fmt, ap);
        deeper.message("%.*s: %s", (int)prefix.length(), prefix.data(), buf);
    }
    else
        deeper.message_v(fmt, ap);
}
