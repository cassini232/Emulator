//
//      UCSD p-System filesystem in user space
//      Copyright (C) 2006, 2007 Peter Miller
//
//      This program is free software; you can redistribute it and/or modify
//      it under the terms of the GNU General Public License as published by
//      the Free Software Foundation; either version 3 of the License, or
//      (at your option) any later version.
//
//      This program is distributed in the hope that it will be useful,
//      but WITHOUT ANY WARRANTY; without even the implied warranty of
//      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//      GNU General Public License for more details.
//
//      You should have received a copy of the GNU General Public License
//      along with this program. If not, see
//      <http://www.gnu.org/licenses/>.
//

#ifndef LIB_QUIT_ATEXIT_LIST_H
#define LIB_QUIT_ATEXIT_LIST_H

#pragma interface "quit_atexit_list"

#include <cstddef>

class quit_atexit; // forward

/**
  * The quit_atexit_list class is used to represent a list of actions to
  * be performed when the program exits.
  */
class quit_atexit_list
{
public:
    /**
      * The destructor.
      */
    virtual ~quit_atexit_list();

    /**
      * The default constructor.
      */
    quit_atexit_list();

    /**
      * The push back method is used to add another item to the end of
      * the list.
      */
    void push_back(quit_atexit *arg);

    /**
      * The run method is used to run all actions on the list, in
      * reverse order.
      */
    void run(int exit_status);

private:
    /**
      * The length instance variable is used to remember how many items
      * are on the list.
      */
    size_t length;

    /**
      * The maximum instance variable is used to remember how many items
      * are allocated to the list.
      */
    size_t maximum;

    /**
      * The item instance variable is used to remember the address of a
      * dynamically allocated array of pointers to action items.
      */
    quit_atexit **item;

    /**
      * The copy constructor.  Do not use.
      */
    quit_atexit_list(const quit_atexit_list &);

    /**
      * The assignment operator.  Do not use.
      */
    quit_atexit_list &operator=(const quit_atexit_list &);
};

#endif // LIB_QUIT_ATEXIT_LIST_H
