//
// UCSD p-System filesystem in user space
// Copyright (C) 2006-2008 Peter Miller
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or (at
// you option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program. If not, see <http://www.gnu.org/licenses/>
//

#include <cstdio>

#include <lib/directory.h>
#include <lib/directory/entry/volume_label.h>


void
directory::print_listing()
{
    printf("%s:\n", volume_label->get_name().c_str());
    unsigned num_blocks = volume_label->get_last_block();
    int num_files = 0;
    for (;;)
    {
        directory_entry::pointer dep = nth(num_files);
        if (!dep)
            break;
        dep->print_listing();
        num_blocks += dep->size_in_blocks();
    }
    printf
    (
        "%d of %d files\n",
        num_files - 1,
        volume_label->maximum_directory_entries()
    );
    unsigned tblks = volume_label->get_eov_block();
    printf
    (
        "%d of %d blocks, %3.1f%% free\n",
        num_blocks,
        tblks,
        100. * (tblks - num_blocks) / (double)tblks
    );
    volume_label->print_listing();
}
