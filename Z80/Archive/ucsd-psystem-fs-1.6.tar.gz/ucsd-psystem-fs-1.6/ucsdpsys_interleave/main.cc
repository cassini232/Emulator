//
// UCSD p-System filesystem in user space
// Copyright (C) 2006, 2007 Peter Miller
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or (at
// you option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program. If not, see <http://www.gnu.org/licenses/>
//

#include <cerrno>
#include <cstdio>
#include <cstring>
#include <unistd.h>

#include <lib/debug.h>
#include <lib/progname.h>
#include <lib/quit.h>
#include <lib/sector_io/apple.h>
#include <lib/sector_io/imd.h>
#include <lib/sector_io/offset.h>
#include <lib/sector_io/pdp.h>
#include <lib/sector_io/raw.h>
#include <lib/sector_io/td0.h>
#include <lib/version.h>


static void
usage()
{
    const char *prog = progname_get();
    fprintf(stderr, "Usage: %s -T<name> -d <infile> <outfile>\n", prog);
    fprintf(stderr, "       %s -T<name> -e <infile> <outfile>\n", prog);
    fprintf(stderr, "       %s -V\n", prog);
    quitter.exit(1);
}


sector_io::pointer
filter_factory(const sector_io::pointer &fp, const char *name)
{
    if (0 == strcasecmp(name, "none") || 0 == strcasecmp(name, "raw"))
        return fp;
    if (0 == strcasecmp(name, "apple"))
        return sector_io_apple::create(fp);
    if (0 == strcasecmp(name, "pdp"))
    {
        sector_io::pointer tmp = sector_io_offset::create(fp, 26 * 128);
        return sector_io_pdp::create(tmp);
    }
    quitter.fatal_error("interleave format \"%s\" unknown", name);
    return fp;
}


int
main(int argc, char **argv)
{
    progname_set(argv[0]);
    const char *interleave_type_name = 0;
    bool encode_flag = false;
    bool decode_flag = false;
    for (;;)
    {
        int c = getopt(argc, argv, "DdeT:V");
        if (c == EOF)
            break;
        switch (c)
        {
        case 'D':
            ++debug_level;
            break;

        case 'd':
            decode_flag = true;
            break;

        case 'e':
            encode_flag = true;
            break;

        case 'T':
            interleave_type_name = optarg;
            break;

        case 'V':
            version_print();
            return 0;

        default:
            usage();
        }
    }
    if (encode_flag + decode_flag != 1)
    {
        quitter.fatal_error
        (
            "you must specify exactly one of the -e (encode) or -d "
                "(decode) options"
        );
    }
    if (argc - optind != 2)
        quitter.fatal_error("two file names must be given");
    const char *infile = argv[optind];
    const char *outfile = argv[optind + 1];
    if (!interleave_type_name)
        quitter.fatal_error("no interleave type (-Tname) specified");

    DEBUG(1, "open input (%s)", infile);
    sector_io::pointer inp = sector_io::factory(infile);
    if (decode_flag)
        inp = filter_factory(inp, interleave_type_name);

    DEBUG(1, "open output (%s)", outfile);
    sector_io::pointer outp = sector_io_raw::create(outfile, false);
    if (encode_flag)
        outp = filter_factory(outp, interleave_type_name);

    //
    // Figure out how many bytes we are going to be processing.
    //
    int rc = inp->size_in_bytes();
    if (rc < 0)
    {
        errno = -rc;
        quitter.fatal_error_with_errno("stat %s", infile);
    }
    size_t size_in_bytes(rc);
    size_t bufsiz = (size_t)1 << 16;
    char *buffer = new char [bufsiz];

    //
    // Read chunks of input and write them to the output
    // until there is nothing more.
    //
    size_t address = 0;
    while (address < size_in_bytes)
    {
        // Slurp as much as possible.
        size_t nbytes = bufsiz;
        if (address + nbytes > size_in_bytes)
            nbytes = size_in_bytes - address;

        DEBUG(2, "inp->read(address = 0x%08lX, buffer = %p, size = %ld)",
            (long)address, buffer, (long)nbytes);
        int err = inp->read(address, buffer, nbytes);
        if (err < 0)
        {
            errno = -err;
            quitter.fatal_error_with_errno("read %s", infile);
        }

        DEBUG(2, "outp->write(address = 0x%08lX, buffer = %p, size = %ld)",
            (long)address, buffer, (long)nbytes);
        err = outp->write(address, buffer, nbytes);
        if (err < 0)
        {
            errno = -err;
            quitter.fatal_error_with_errno("write %s", infile);
        }

        address += nbytes;
    }
    rc = outp->sync();
    if (rc < 0)
    {
        errno = -rc;
        quitter.fatal_error_with_errno("sync %s", infile);
    }
    if (rc < 0)
    DEBUG(1, "close");
    delete buffer;
    inp.reset();
    outp.reset();
    return 0;
}
