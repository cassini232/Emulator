//
// UCSD p-System filesystem in user space
// Copyright (C) 2006, 2007 Peter Miller
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or (at
// you option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program. If not, see <http://www.gnu.org/licenses/>
//

#include <cstdio>
#include <cstdlib>
#include <fcntl.h>
#include <unistd.h>

#include <lib/progname.h>
#include <lib/quit.h>
#include <lib/version.h>


static void
usage()
{
    const char *prog = progname_get();
    fprintf(stderr, "Usage: %s [ <option>... ] <filename>\n", prog);
    fprintf(stderr, "       %s -V\n", prog);
    quitter.exit(1);
}


static void
fill_with_noise(unsigned char *buffer, size_t size)
{
    for (size_t j = 0; j < size; ++j)
        buffer[j] = rand() >> 7;
}


static void
test_write_then_read(const char *filename, size_t nbytes)
{
    int fd = open(filename, O_RDWR | O_CREAT | O_TRUNC, 0666);
    if (fd < 0)
        quitter.fatal_error_with_errno("open %s", filename);

    //
    // Write a partial block of data at the start of the file.
    //
    size_t nbytes_even = (nbytes + 1023) & -1023;
    unsigned char *buffer = new unsigned char [nbytes_even];
    fill_with_noise(buffer, sizeof(buffer));
    int n = write(fd, buffer, nbytes);
    if (n < 0)
        quitter.fatal_error_with_errno("write %s", filename);
    if ((size_t)n != nbytes)
    {
        quitter.fatal_error_with_errno
        (
            "write %s: wrong size: gave %d, got %d",
            filename,
            nbytes,
            n
        );
    }

    //
    // check that fstat has the same data as we expect.
    //
    struct stat st;
    if (fstat(fd, &st) < 0)
        quitter.fatal_error_with_errno("fstat %s", filename);
    if (st.st_size != nbytes)
    {
        quitter.fatal_error_with_errno
        (
            "fstat %s: wrong size: expected %d, got %d",
            filename,
            (int)nbytes,
            (int)st.st_size
        );
    }

    //
    // Now read it back and see if it is correct.
    //
    char *buf2 = new char [nbytes_even];
    if (lseek(fd, 0, SEEK_SET) < 0)
        quitter.fatal_error_with_errno("seek %s", filename);
    n = read(fd, buf2, nbytes_even);
    if (n < 0)
        quitter.fatal_error_with_errno("read %s", filename);
    if ((size_t)n != nbytes)
    {
        quitter.fatal_error_with_errno
        (
            "read %s: wrong size: expected %d, got %d",
            filename,
            nbytes,
            n
        );
    }

    if (close(fd) < 0)
        quitter.fatal_error_with_errno("close %s", filename);

    delete buf2;
    delete buffer;
}


static void
test_basic_write_then_read(const char *filename)
{
    // Test less than one block
    test_write_then_read(filename, 107);
}


static void
test_block_write_then_read(const char *filename)
{
    // Test exact block multiple.
    test_write_then_read(filename, 1024);
}


static void
test_write_with_holes(const char *filename)
{
    int fd = open(filename, O_RDWR | O_CREAT | O_TRUNC, 0666);
    if (fd < 0)
        quitter.fatal_error_with_errno("open %s", filename);

    if (lseek(fd, 521, SEEK_SET) < 0)
        quitter.fatal_error_with_errno("lseek %s", filename);

    unsigned char buffer[523];
    fill_with_noise(buffer, sizeof(buffer));
    if (write(fd, buffer, sizeof(buffer)) < 0)
        quitter.fatal_error_with_errno("write %s", filename);

    if (lseek(fd, 1051, SEEK_SET) < 0)
        quitter.fatal_error_with_errno("lseek %s", filename);

    unsigned char buffer2[541];
    fill_with_noise(buffer2, sizeof(buffer2));
    if (write(fd, buffer2, sizeof(buffer2)) < 0)
        quitter.fatal_error_with_errno("write %s", filename);

    if (close(fd) < 0)
        quitter.fatal_error_with_errno("close %s", filename);

    //
    // Now go back and make sure the data are correct.
    //
    FILE *fp = fopen(filename, "rb");
    if (!fp)
        quitter.fatal_error_with_errno("open %s", filename);
    for (int addr = 0; ; ++addr)
    {
        int c = getc(fp);
        if (c == EOF)
        {
            if (ferror(fp))
                quitter.fatal_error_with_errno("read %s", filename);
            break;
        }
        if (addr < 521)
        {
            if (c != 0)
                quitter.fatal_error("%s: zero padding broken", filename);
        }
        else if (addr < 521 + 523)
        {
            if (c != buffer[addr - 521])
            {
                quitter.fatal_error
                (
                    "%s: data wrong (addr %d, expected %d, got %d)",
                    filename,
                    addr,
                    buffer[addr - 521],
                    c
                );
            }
        }
        else if (addr < 1051)
        {
            if (c != 0)
                quitter.fatal_error("%s: zero padding broken", filename);
        }
        else if (addr < 1051 +  541)
        {
            if (c != buffer2[addr - 1051])
            {
                quitter.fatal_error
                (
                    "%s: data wrong (addr %d, expected %d, got %d)",
                    filename,
                    addr,
                    buffer2[addr - 1051],
                    c
                );
            }
        }
        else
        {
            quitter.fatal_error("%s: file too long", filename);
        }
    }
    fclose(fp);
}


static void
test_truncate_with_holes(const char *filename)
{
    int fd = open(filename, O_RDWR | O_CREAT | O_TRUNC, 0666);
    if (fd < 0)
        quitter.fatal_error_with_errno("open %s", filename);

    unsigned char buffer[523];
    fill_with_noise(buffer, sizeof(buffer));
    if (write(fd, buffer, sizeof(buffer)) < 0)
        quitter.fatal_error_with_errno("write %s", filename);

    if (ftruncate(fd, 1051) < 0)
        quitter.fatal_error_with_errno("truncate %s", filename);

    if (close(fd) < 0)
        quitter.fatal_error_with_errno("close %s", filename);

    //
    // Now go back and make sure the data are correct.
    //
    FILE *fp = fopen(filename, "rb");
    if (!fp)
        quitter.fatal_error_with_errno("open %s", filename);
    for (int addr = 0; ; ++addr)
    {
        int c = getc(fp);
        if (c == EOF)
        {
            if (ferror(fp))
                quitter.fatal_error_with_errno("read %s", filename);
            break;
        }
        if (addr < 523)
        {
            if (c != buffer[addr])
            {
                quitter.fatal_error
                (
                    "%s: data wrong (addr %d, expected %d, got %d)",
                    filename,
                    addr,
                    buffer[addr],
                    c
                );
            }
        }
        else if (addr < 1051)
        {
            if (c != 0)
                quitter.fatal_error("%s: zero padding broken", filename);
        }
        else
        {
            quitter.fatal_error("%s: file too long", filename);
        }
    }
    fclose(fp);
}


int
main(int argc, char **argv)
{
    srand(getpid());
    progname_set(argv[0]);
    void (*func)(const char *) = 0;
    for (;;)
    {
        int c = getopt(argc, argv, "bceS:tV");
        if (c == EOF)
            break;
        switch (c)
        {
        case 'b':
            func = test_basic_write_then_read;
            break;

        case 'c':
            func = test_block_write_then_read;
            break;

        case 'e':
            func = test_write_with_holes;
            break;

        case 'S':
            srand(atoi(optarg));
            break;

        case 't':
            func = test_truncate_with_holes;
            break;

        case 'V':
            version_print();
            return 0;

        default:
            usage();
        }
    }
    if (!func)
        usage();
    if (optind + 1 != argc)
        usage();
    const char *filename = argv[optind];
    func(filename);
    return 0;
}
