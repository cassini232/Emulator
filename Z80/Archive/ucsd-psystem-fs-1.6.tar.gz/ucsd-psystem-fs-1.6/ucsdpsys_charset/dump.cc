//
// UCSD p-System filesystem in user space
// Copyright (C) 2006, 2007 Peter Miller
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or (at
// you option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program. If not, see <http://www.gnu.org/licenses/>
//

#include <cctype>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <unistd.h>

#include <lib/quit.h>
#include <ucsdpsys_charset/dump.h>


static bool
stdio_stream(const char *filename)
{
    return (!filename || !*filename || (filename[0] == '-' && !filename[1]));
}


static void
read_the_data(const char *ifn, unsigned char *data, size_t len)
{
    int fd = 0;
    if (!stdio_stream(ifn))
    {
        fd = open(ifn, O_RDONLY);
        if (fd < 0)
            quitter.fatal_error_with_errno("open %s", ifn);
    }
    ssize_t n = read(fd, data, len);
    if (n < 0)
        quitter.fatal_error_with_errno("read %s", ifn);
    if ((size_t)n < len && n < 1024)
    {
        quitter.message("read %s: got %d, expected %d", ifn, (int)n, (int)len);
        memset(data + n, 0, len - n);
    }
    if ((size_t)n < len)
        memset(data + n, 0, len - n);
    if (fd != 0)
        close(fd);
}


static void
print_bits(int x)
{
    printf("    \"");
    for (int bit = 1; bit < 256; bit <<= 1)
    {
        if (x & bit)
            putchar('X');
        else
            putchar(' ');
    }
    printf("\",\n");
}


void
dump(const char *ifn, const char *ofn)
{
    unsigned char data[256 * 8];
    read_the_data(ifn, data, sizeof(data));

    if (stdio_stream(ofn))
        ofn = "stdout";
    else
    {
        if (!freopen(ofn, "w", stdout))
            quitter.fatal_error_with_errno("open %s", ofn);
    }
    printf("#\n");
    printf("# This file defines the shapes of the characters for\n");
    printf("# drawing them on the screen.  This what is known as a\n");
    printf("# bit-mapped font.\n");
    printf("#\n");
    printf("# Note that font outlines and bit-mapped fonts are not\n");
    printf("# eligible for copyright protection.  Only fonts which\n");
    printf("# contain computer code (e.g. some PostScript fonts)\n");
    printf("# are eligible for copyright protection.\n");
    printf("#\n");
    for (int j = 0; j < 256; ++j)
    {
        unsigned char *gp = data + j * 8;
        if (gp[0] + gp[1] + gp[2] + gp[3] + gp[4] + gp[5] + gp[6] + gp[7] == 0)
            continue;
        if (j == '\\' || j == '\'')
            printf("'\\%c'", j);
        else if (isprint(j))
            printf("'%c'", j);
        else
            printf("%d", j);
        printf(" = {\n");
        for (int k = 0; k < 8; ++k)
            print_bits(gp[7 - k]);
        printf("};\n");
    }
    if (fflush(stdout))
        quitter.fatal_error_with_errno("write %s", ofn);
}
