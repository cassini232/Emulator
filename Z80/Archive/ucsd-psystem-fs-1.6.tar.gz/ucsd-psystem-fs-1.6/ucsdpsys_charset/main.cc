//
// UCSD p-System filesystem in user space
// Copyright (C) 2006, 2007 Peter Miller
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or (at
// you option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program. If not, see <http://www.gnu.org/licenses/>
//

#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <unistd.h>

#include <lib/progname.h>
#include <lib/version.h>
#include <ucsdpsys_charset/dump.h>
#include <ucsdpsys_charset/encode.h>


static void
usage()
{
    const char *prog = progname_get();
    fprintf(stderr, "Usage: %s -d [ <infile> [ <outfile> ]]\n", prog);
    fprintf(stderr, "       %s -e [ <infile> [ <outfile> ]]\n", prog);
    fprintf(stderr, "       %s -V\n", prog);
    exit(1);
}


int
main(int argc, char **argv)
{
    progname_set(argv[0]);
    void (*func)(const char *, const char *) = 0;
    for (;;)
    {
        int c = getopt(argc, argv, "deiV");
        if (c == EOF)
            break;
        switch (c)
        {
        case 'd':
            func = dump;
            break;

        case 'e':
            func = encode;
            break;

        case 'i':
            func = encode_include;
            break;

        case 'V':
            version_print();
            return 0;

        default:
            usage();
        }
    }
    if (!func)
        usage();
    const char *ifn = "-";
    const char *ofn = "-";
    switch (argc - optind)
    {
    case 0:
        break;

    case 2:
        ofn = argv[optind + 1];
        // Fall through...

    case 1:
        ifn = argv[optind];
        break;

    default:
        usage();
    }

    func(ifn, ofn);

    return 0;
}
