//
// UCSD p-System filesystem in user space
// Copyright (C) 2006, 2007 Peter Miller
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or (at
// you option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program. If not, see <http://www.gnu.org/licenses/>
//

#include <cctype>
#include <cstdarg>
#include <cstdio>
#include <cstring>

#include <lib/quit.h>
#include <lib/rcstring.h>
#include <lib/rcstring/accumulator.h>
#include <ucsdpsys_charset/encode.h>


static const char *ifn;
static FILE *ifp;
static int linum;


static bool
stdio_stream(const char *fn)
{
    return (!fn | !*fn || (fn[0] == '-' && !fn[1]));
}


static void
parse_error(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    char buffer[200];
    vsnprintf(buffer, sizeof(buffer), fmt, ap);
    va_end(ap);

    quitter.fatal_error("%s: %d: %s", ifn, linum, buffer);
}


static void
syntax_error()
{
    quitter.fatal_error("%s: %d: syntax error", ifn, linum);
}


static int
string_to_bits(const char *s)
{
    int result = 0;
    int bit = 1;
    while (*s)
    {
        if (bit >= 256)
            parse_error("invalid bit pattern");
        if (*s != ' ')
            result |= bit;
        bit <<= 1;
        ++s;
    }
    return result;
}


enum token_t
{
    token_eof,
    token_integer,
    token_character,
    token_comma,
    token_string,
    token_eq,
    token_semicolon,
    token_lbrace,
    token_rbrace,
    token_junk
};


static token_t tok;
static int token_value_integer;
static rcstring token_value_string;


static int
lex_getc()
{
    int c = getc(ifp);
    if (c == EOF)
    {
        if (ferror(ifp))
            quitter.fatal_error_with_errno("read %s", ifn);
    }
    else if (c == '\n')
        ++linum;
    return c;
}


static void
lex_ungetc(int c)
{
    if (c != EOF)
    {
        if (c == '\n')
            --linum;
        ungetc(c, ifp);
    }
}


static int
escape()
{
    int c = lex_getc();
    switch (c)
    {
    case EOF:
    case '\n':
    case '\r':
        syntax_error();

    case '0': case '1': case '2': case '3':
    case '4': case '5': case '6': case '7':
        {
            int n = 0;
            for (int ndig = 0; ndig < 3; ++ndig)
            {
                n = n * 8 + c - '0';
                c = lex_getc();
                switch (c)
                {
                case '0': case '1': case '2': case '3':
                case '4': case '5': case '6': case '7':
                    break;

                default:
                    lex_ungetc(c);
                    return n;
                }
            }
            return n;
        }

    default:
        return c;
    }
}


static token_t
token_next()
{
    static rcstring_accumulator ac;
    ac.clear();
    for (;;)
    {
        int c = lex_getc();
        switch (c)
        {
        case EOF:
            if (ferror(ifp))
                quitter.fatal_error_with_errno("read %s", ifn);
            tok = token_eof;
            return tok;

        case ' ':
        case '\f':
        case '\n':
        case '\r':
        case '\t':
        case '\v':
            break;

        case '#':
            for (;;)
            {
                c = lex_getc();
                if (c == EOF || c == '\n')
                    break;
            }
            break;

        case '=':
            tok = token_eq;
            return tok;

        case ',':
            tok = token_comma;
            return tok;

        case ';':
            tok = token_semicolon;
            return tok;

        case '{':
            tok = token_lbrace;
            return tok;

        case '}':
            tok = token_rbrace;
            return tok;

        case '\'':
            c = lex_getc();
            if (c == EOF || c == '\'')
                syntax_error();
            if (c == '\\')
                c = escape();
            token_value_integer = c;
            c = lex_getc();
            if (c != '\'')
                syntax_error();
            tok = token_character;
            return tok;

        case '"':
            for (;;)
            {
                c = lex_getc();
                if (c == EOF || c == '"')
                    break;
                if (c == '\n')
                    syntax_error();
                if (c == '\\')
                    c = escape();
                ac.push_back((char)c);
            }
            token_value_string = ac.mkstr();
            tok = token_string;
            return tok;

        case '0': case '1': case '2': case '3': case '4':
        case '5': case '6': case '7': case '8': case '9':
            token_value_integer = 0;
            for (;;)
            {
                token_value_integer = token_value_integer * 10 + c - '0';
                c = lex_getc();
                switch (c)
                {
                case '0': case '1': case '2': case '3': case '4':
                case '5': case '6': case '7': case '8': case '9':
                    break;

                default:
                    lex_ungetc(c);
                    tok = token_integer;
                    return tok;
                }
            }

        default:
            tok = token_junk;
            return tok;
        }
    }
}


static void
slurp(const char *infile, unsigned char *data)
{
    ifn = infile;
    ifp = stdin;
    if (stdio_stream(ifn))
        ifn = "stdin";
    else
    {
        ifp = fopen(ifn, "r");
        if (!ifp)
            quitter.fatal_error_with_errno("open %s", ifn);
    }
    linum = 1;
    int used[256];
    for (int j = 0; j < 256; ++j)
        used[j] = 0;
    for (;;)
    {
        token_next();
        if (tok == token_eof)
            break;
        if (tok != token_integer && tok != token_character)
            syntax_error();
        int c = token_value_integer;
        if (c < 0 || c >= 256)
            parse_error("character %d out of range", c);
        if (used[c])
        {
            parse_error
            (
                "character %d duplicate definition (first defined on line %d)",
                c,
                used[c]
            );
        }
        else
            used[c] = linum;
        if (token_next() != token_eq)
            syntax_error();
        if (token_next() != token_lbrace)
            syntax_error();
        token_next();
        unsigned char *gp = data + 8 * c;
        memset(gp, 0, 8);
        // Next comes (up to) 8 string constants.
        for (int j = 0; j < 8; ++j)
        {
            if (tok != token_string)
                syntax_error();
            gp[7 - j] = string_to_bits(token_value_string.c_str());
            token_next();
            if (tok != token_comma)
                break;
            token_next();
            if (tok != token_string)
                break;
        }
        if (tok != token_rbrace)
            syntax_error();
        if (token_next() != token_semicolon)
            syntax_error();
    }
    if (ifp != stdin)
        fclose(ifp);
}


void
encode(const char *infile, const char *ofn)
{
    unsigned char data[256 * 8];
    memset(data, 0, sizeof(data));

    slurp(infile, data);

    //
    // Now write the data back out.
    //
    FILE *ofp = stdout;
    if (stdio_stream(ofn))
        ofn = "stdout";
    else
    {
        ofp = fopen(ofn, "wb");
        if (!ofp)
            quitter.fatal_error_with_errno("open %s", ofn);
    }
    fwrite(data, 1, sizeof(data), ofp);
    if (fflush(ofp))
        quitter.fatal_error_with_errno("write %s", ofn);
    if (fclose(ofp))
        quitter.fatal_error_with_errno("close %s", ofn);
}


void
encode_include(const char *infile, const char *ofn)
{
    unsigned char data[256 * 8];
    memset(data, 0, sizeof(data));

    slurp(infile, data);

    //
    // Now write the data back out.
    //
    FILE *ofp = stdout;
    if (stdio_stream(ofn))
        ofn = "stdout";
    else
    {
        ofp = fopen(ofn, "w");
        if (!ofp)
            quitter.fatal_error_with_errno("open %s", ofn);
    }
    for (unsigned j = 0; j < sizeof(data); ++j)
    {
        if ((j & 7) == 0)
            putc('\t', ofp);
        else
            putc(' ', ofp);
        fprintf(ofp, "0x%02X,", data[j]);
        if ((j & 7) == 7)
        {
            unsigned char c = j >> 3;
            if (c == '\'' || c == '\\')
                fprintf(ofp, " /* '\\%c' */\n", c);
            else if (isprint(c))
                fprintf(ofp, " /* '%c' */\n", c);
            else
                fprintf(ofp, " /* %3d */\n", c);
        }
    }
    if (fflush(ofp))
        quitter.fatal_error_with_errno("write %s", ofn);
    if (fclose(ofp))
        quitter.fatal_error_with_errno("close %s", ofn);
}
