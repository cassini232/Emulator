//
// UCSD p-System filesystem in user space
// Copyright (C) 2006, 2007 Peter Miller
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or (at
// you option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program. If not, see <http://www.gnu.org/licenses/>
//

#include <cstdio>
#include <unistd.h>

#include <lib/debug.h>
#include <lib/directory.h>
#include <lib/progname.h>
#include <lib/quit.h>
#include <lib/version.h>


static void
usage()
{
    const char *prog = progname_get();
    fprintf(stderr, "Usage: %s [ <option>... ] <volume>\n", prog);
    fprintf(stderr, "       %s -V\n", prog);
    quitter.exit(1);
}


int
main(int argc, char **argv)
{
    concern_t concern_level = concern_check;

    //
    // Parse the command line options.
    //
    progname_set(argv[0]);
    bool read_only_flag = false;
    for (;;)
    {
        int c = getopt(argc, argv, "fDrV");
        if (c < 0)
            break;
        switch (c)
        {
        case 'D':
            ++debug_level;
            break;

        case 'f':
            concern_level = concern_repair;
            break;

        case 'r':
            // read only
            read_only_flag = true;
            break;

        case 'V':
            version_print();
            return 0;

        default:
            usage();
        }
    }
    if (optind + 1 != argc)
        usage();
    const char *filename = argv[optind];

    //
    // Make sure we haven't been asked to do the impossible.
    //
    if (concern_level == concern_repair && read_only_flag)
        quitter.fatal_error("unable to fix problems (-f) if read only (-r)");

    //
    // Open the volume, and make sure it has the right format.
    //
    directory *volume =
        directory::factory(filename, read_only_flag, concern_level);

    //
    // Close down the volume.
    // This may do essential flush operations.
    //
    delete volume;
    volume = 0;

    //
    // Report success.
    //
    return 0;
}
