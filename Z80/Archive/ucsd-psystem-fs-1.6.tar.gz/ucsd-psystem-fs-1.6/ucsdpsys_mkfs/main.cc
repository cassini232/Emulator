//
// UCSD p-System filesystem in user space
// Copyright (C) 2006, 2007 Peter Miller
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or (at
// you option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program. If not, see <http://www.gnu.org/licenses/>
//

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fcntl.h>
#include <unistd.h>

#include <lib/debug.h>
#include <lib/directory.h>
#include <lib/quit.h>
#include <lib/progname.h>
#include <lib/sector_io/raw.h>
#include <lib/sector_io/apple.h>
#include <lib/version.h>

//
// The MAX_DISK_SIZE_KB define is the maximum size of a disk volume, in
// kilobytes.
//
// The size of the disk, in 512-byte blocks, is stored in the volume
// label, in a 16-bit field called "deovblk".  Codeing practices being
// what they are (i.e. usually sloppy) it is unlikely that very much
// code can actually cope with deovblk of 65535, or any other value
// which looks negative (anything in the range 32768 to 65535).  Erring
// on the side of caution, we should aim for deovblk to be 32767 or
// smaller.  This gives a maximum disk size of 16384KB - 0.5KB.
//
// A second constraint is Apple ][ Pascal interleaved disks.  These
// operate within 16 256-byte sectors.  Thus, disk sizes must be a
// multiple of 4KB.  This gives a maximum disk size of 16384KB - 4KB =
// 16380KB.
//
#define MAX_DISK_SIZE_KB 16380


/**
  * The zero_whole_volume function is used to create an initial disk
  * image, completely filled with zero data (not just one big hole).
  *
  * @param filename
  *     The file to be written.
  * @param size_kb
  *     The size, in kilobytes, of the file to be written.
  */
static void
zero_whole_volume(const char *filename, unsigned size_kb)
{
    int fd = open(filename, O_RDWR | O_CREAT | O_TRUNC, 0666);
    if (fd < 0)
        quitter.fatal_error_with_errno("open %s", filename);
    struct stat st;
    if (fstat(fd, &st) < 0)
        quitter.fatal_error_with_errno("stat %s", filename);
    if (!S_ISREG(st.st_mode))
        quitter.fatal_error("%s: not a regular file", filename);

    //
    // FIXME: At the moment, we only know how to build Apple volumes.
    // The interleaving code works on tracks of 16 sectors, each of 256
    // bytes.  The Apple ][ disks had 35 tracks.
    //
    char block[256 * 16];
    memset(block, 0, sizeof(block));
    size_t ntracks = size_kb / 4;
    for (unsigned track = 0; track < ntracks; ++track)
    {
        int err = write(fd, block, sizeof(block));
        if (err < 0)
            quitter.fatal_error_with_errno("write %s", filename);
    }
    if (close(fd) < 0)
        quitter.fatal_error_with_errno("close %s", filename);
}


static void
usage()
{
    const char *prog = progname_get();
    fprintf(stderr, "Usage: %s <filename>\n", prog);
    fprintf(stderr, "       %s -V\n", prog);
    quitter.exit(1);
}


int
main(int argc, char **argv)
{
    progname_set(argv[0]);
    bool interleave = false;
    rcstring volid;
    bool twin = false;

    // Apple ][ Pascal disks were this size
    unsigned size_kb = 140;

    for (;;)
    {
        int c = getopt(argc, argv, "B:DiL:tV");
        if (c == EOF)
            break;
        switch (c)
        {
        case 'B':
            size_kb = atoi(optarg);
            if (size_kb & 3)
            {
                quitter.fatal_error
                (
                    "the size given (%dKB) is not a multiple of 4KB",
                    size_kb
                );
            }
            if (size_kb < 4 || size_kb > MAX_DISK_SIZE_KB)
            {
                quitter.fatal_error
                (
                    "the size given (%dKB) is not in the range 4 to %d",
                    size_kb,
                    MAX_DISK_SIZE_KB
                );
            }
            break;

        case 'D':
            ++debug_level;
            break;

        case 'i':
            interleave = true;
            break;

        case 'L':
            volid = optarg;
            break;

        case 't':
            twin = true;
            break;

        case 'V':
            version_print();
            return 0;

        default:
            usage();
        }
    }
    if (optind + 1 != argc)
        usage();
    const char *filename = argv[optind];

    zero_whole_volume(filename, size_kb);

    sector_io::pointer raw = sector_io_raw::create(filename);
    sector_io::pointer cooked =
        (interleave ? sector_io_apple::create(raw) : raw);
    directory dir(cooked);
    dir.mkfs(volid, twin);
    dir.meta_sync();

    return 0;
}
