//
// UCSD p-System filesystem in user space
// Copyright (C) 2006-2008 Peter Miller
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or (at
// you option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program. If not, see <http://www.gnu.org/licenses/>
//

#include <cassert>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>

#include <lib/debug.h>
#include <lib/directory.h>
#include <lib/directory/entry.h>
#include <lib/input/file.h>
#include <lib/input/psystem.h>
#include <lib/output/file.h>
#include <lib/output/psystem.h>
#include <lib/output/text_decode.h>
#include <lib/output/text_encode.h>
#include <lib/progname.h>
#include <lib/quit.h>
#include <lib/rcstring/list.h>
#include <lib/version.h>


static void
usage()
{
    const char *prog = progname_get();
    fprintf(stderr, "Usage: %s -f <disk.image> -l\n", prog);
    fprintf(stderr, "       %s -f <disk.image> -g <file.to.get>...\n", prog);
    fprintf(stderr, "       %s -f <disk.image> -p <file.to.put>...\n", prog);
    fprintf(stderr, "       %s -f <disk.image> -r <file.to.remove>...\n", prog);
    fprintf(stderr, "       %s -V\n", prog);
    quitter.exit(1);
}


static mode_t
get_umask()
{
    mode_t um = umask(0);
    umask(um);
    return (um & 0777);
}


static bool all_binary;


static void
get(directory *volume, const rcstring &fspec)
{
    rcstring unix_filename(fspec);
    rcstring ucsd_filename(unix_filename.basename());
    const char *cp = strchr(fspec.c_str(), '=');
    if (cp)
    {
        unix_filename = rcstring(fspec.c_str(), cp - fspec.c_str());
        ucsd_filename = rcstring(cp + 1);
    }

    directory_entry::pointer dep = volume->find(ucsd_filename);
    if (!dep)
    {
        errno = ENOENT;
        quitter.fatal_error_with_errno
        (
            "open %s:%s",
            volume->get_volume_name().c_str(),
            ucsd_filename.c_str()
        );
    }

    input::pointer in = input_psystem::create(dep);
    struct stat stbuf;
    in->fstat(stbuf);
    bool binary = all_binary || !dep->is_text_kind();
    output::pointer out = output_file::create(unix_filename, binary);
    if (!binary)
        out = output_text_decode::create(out);

    //
    // Copy the input to the output.
    //
    out->write(in);
    out->flush();

    //
    // Preserve the utimes (as far as possible, anyway).
    //
    struct timespec tv[2];
    tv[0].tv_sec = stbuf.st_atime;
    tv[0].tv_nsec = 0;
    tv[1].tv_sec = stbuf.st_mtime;
    tv[1].tv_nsec = 0;
    out->utime_ns(tv);
}


static void
get_dir(directory *volume, const rcstring &dir)
{
    directory_entry::pointer dep = volume->find("/");
    assert(dep);
    rcstring_list names;
    int err = dep->get_directory_entry_names(names);
    if (err < 0)
    {
        errno = err;
        quitter.fatal_error("getdents %s:", volume->get_volume_name().c_str());
    }
    for (size_t j = 0; j < names.size(); ++j)
    {
        rcstring name = names[j];
        rcstring path = dir + "/" + name.downcase();
        get(volume, path + "=" + name);
    }
}


static void
put(directory *volume, const rcstring &fspec)
{
    rcstring unix_filename(fspec);
    rcstring ucsd_filename(unix_filename.basename());
    const char *cp = strchr(fspec.c_str(), '=');
    if (cp)
    {
        ucsd_filename = rcstring(fspec.c_str(), cp - fspec.c_str());
        unix_filename = rcstring(cp + 1);
    }

    input::pointer in = input_file::create(unix_filename);
    struct stat st;
    in->fstat(st);

    directory_entry::pointer dep = volume->find(ucsd_filename);
    if (!dep)
    {
        dep = volume->find("/");
        assert(dep);
        mode_t mode = S_IFREG + (0666 & ~get_umask());
        int err = dep->mknod(ucsd_filename, mode, 0);
        if (err < 0)
        {
            errno = -err;
            quitter.fatal_error_with_errno
            (
                "create %s:%s",
                volume->get_volume_name().c_str(),
                ucsd_filename.c_str()
            );
        }
        dep = volume->find(ucsd_filename);
        assert(dep);
    }

    output::pointer out = output_psystem::create(dep);
    if (!all_binary && dep->is_text_kind())
        out = output_text_encode::create(out);

    out->write(in);
    out->flush();

    //
    // Preserve the utimes (as far as possible, anyway).
    //
    struct timespec tv[2];
    tv[0].tv_sec = st.st_atime;
    tv[0].tv_nsec = 0;
    tv[1].tv_sec = st.st_mtime;
    tv[1].tv_nsec = 0;
    out->utime_ns(tv);
}


static void
put_dir(directory *volume, const rcstring &dir)
{
    DIR *dp = opendir(dir.c_str());
    if (!dp)
        quitter.fatal_error("opendir %s", dir.quote_c().c_str());
    for (;;)
    {
        dirent *dep = readdir(dp);
        if (!dep)
            break;
        rcstring name(dep->d_name);
        rcstring path = dir + "/" + name;
        struct stat st;
        if (stat(path.c_str(), &st) < 0)
            quitter.fatal_error_with_errno("stat %s", path.quote_c().c_str());
        if (S_ISREG(st.st_mode))
            put(volume, name.upcase() + "=" + path);
    }
    closedir(dp);
}


static void
remove(directory *volume, const rcstring &filename)
{
    directory_entry::pointer dep = volume->find(filename);
    if (!dep)
    {
        errno = ENOENT;
        quitter.fatal_error_with_errno
        (
            "remove %s:%s",
            volume->get_volume_name().c_str(),
            filename.c_str()
        );
    }
    int err = dep->unlink();
    if (err < 0)
    {
        errno = -err;
        quitter.fatal_error_with_errno
        (
            "unlink %s:%s",
            volume->get_volume_name().c_str(),
            filename.c_str()
        );
    }
}


static bool
is_a_directory(const rcstring &filename)
{
    struct stat st;
    if (stat(filename.c_str(), &st) < 0)
        return false;
    return S_ISDIR(st.st_mode);
}


int
main(int argc, char **argv)
{
    progname_set(argv[0]);
    bool listing_flag = false;
    bool get_flag = false;
    bool put_flag = false;
    bool remove_flag = false;
    const char *disk_image_filename = 0;
    bool text_on_the_fly = false;
    for (;;)
    {
        int c = getopt(argc, argv, "BDf:glprtV");
        if (c == EOF)
            break;
        switch (c)
        {
        case 'B':
            all_binary = true;
            break;

        case 'D':
            ++debug_level;
            break;

        case 'f':
            disk_image_filename = optarg;
            break;

        case 'g':
            get_flag = true;
            break;

        case 'l':
            listing_flag = true;
            break;

        case 'p':
            put_flag = true;
            break;

        case 'r':
            remove_flag = true;
            break;

        case 't':
            text_on_the_fly = true;
            all_binary = true;
            break;

        case 'V':
            version_print();
            return 0;

        default:
            usage();
        }
    }
    if (!disk_image_filename)
    {
        if (optind >= argc)
            quitter.fatal_error("no disk image file name specified");
        // Ugly, but probably what the user meant.
        disk_image_filename = argv[optind++];
    }
    if (!listing_flag && !get_flag && !put_flag && !remove_flag)
        listing_flag = true;
    if (get_flag + put_flag + remove_flag > 1)
        usage();
    if (optind < argc && !get_flag && !put_flag && !remove_flag)
        usage();

    //
    // Open the volume, and make sure it has the right format.
    //
    bool read_only_flag = !put_flag && !remove_flag;
    directory *volume = directory::factory(disk_image_filename, read_only_flag);
    if (text_on_the_fly)
        volume->convert_text_on_the_fly();

    //
    // Chew on the volume, as requested.
    //
    while (optind < argc)
    {
        rcstring filename = argv[optind++];
        if (put_flag)
        {
            if (is_a_directory(filename))
                put_dir(volume, filename);
            else
                put(volume, filename);
        }
        if (get_flag)
        {
            if (is_a_directory(filename))
                get_dir(volume, filename);
            else
                get(volume, filename);
        }
        if (remove_flag)
            remove(volume, filename);
    }

    //
    // Show the contents of the volume.
    //
    if (listing_flag)
        volume->print_listing();

    //
    // Close down the volume.
    // This may do essential flush operations.
    //
    delete volume;
    volume = 0;

    //
    // Report success
    //
    return 0;
}
