//
// UCSD p-System filesystem in user space
// Copyright (C) 2006-2008 Peter Miller
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or (at
// you option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program. If not, see <http://www.gnu.org/licenses/>
//

#include <cstdio>
#include <cstdlib>
#include <unistd.h>

#include <lib/config.h>
#include <lib/progname.h>
#include <lib/quit.h>
#include <lib/rcstring.h>
#include <lib/version.h>


static void
usage()
{
    const char *prog = progname_get();
    fprintf(stderr, "Usage: %s <mount-point>\n", prog);
    fprintf(stderr, "       %s -V\n", prog);
    quitter.exit(1);
}


int
main(int argc, char **argv)
{
    progname_set(argv[0]);
    for (;;)
    {
        int c = getopt(argc, argv, "V");
        if (c == EOF)
            break;
        switch (c)
        {
        case 'V':
            version_print();
            return 0;

        default:
            usage();
        }
    }
    if (optind + 1 != argc)
        usage();

    // we may need to try more than once, because of the asynchronous
    // nature of the daemon process FUSE talks to.
    rcstring dir(argv[optind]);
    rcstring command = "fusermount -u " + dir.quote_shell();
    int ntries = 0;
    int maximum_ms = 3000;
    int sleep_ms = 20;
    for (int cumulative_ms = 0; ntries < 1000; )
    {
        if (cumulative_ms >= maximum_ms)
            quitter.fatal_error("failed after %d attempts", ntries);
        if (ntries)
        {
#ifdef HAVE_USLEEP
            usleep(sleep_ms * 1000);
            cumulative_ms += sleep_ms;
#else
            int s = (sleep_ms + 999) / 1000;
            sleep(s);
            cumulative_ms += s * 1000;
#endif
            sleep_ms *= 2;
        }
        ++ntries;
        if (0 == system(command.c_str()))
            break;
    }
    if (ntries > 1)
        quitter.message("succeeded after %d attempts", ntries);
    return 0;
}
